# Susan 随机组句语法专场｜核心版与独立学习笔记

在线阅读：https://jingjie0209.github.io/susan-grammar-study-notes/

[核心速读](core-index.html) · [本次新增 A-051](core-index.html#core-A-051)

[句型应答阶梯 A-001～A-030](ladder-index.html) · [本次新增 A-021～A-030](ladder-index.html#ladder-A-021) · [下载本组阶梯 ZIP](downloads/study-ladders-A021-A030.zip) · [下载全部阶梯](downloads/study-ladders-all.zip)

本次新增10份阶梯，累计30份；按使用信号而非固定年龄分层，每份独立HTML、Markdown与1页PDF。旧核心正文与详细原件保留，历史阶梯批次ZIP保留；阶梯不算新增课程。

原视频合集：https://space.bilibili.com/3546835260016842/lists/7970912?type=season

## 当前范围（2026 年 10 月 16 日）

- 目录：91 条来源视频，51 小时 17 分 33 秒；目录数量基于 2026 年 10 月 10 日快照，不代表今天重新抓取。
- 已完成：52 份来源笔记，对应 A-001～A-051 共 **51 讲不同内容**；未完成的来源仍只有目录。
- A-003 两次上传为同一内容，核心目录合并展示，来源文件分别保留，不算成两讲。
- 每讲均有核心版（约 1–2 分钟），只保留重点、练法与易错提醒。首页优先核心版，详细 HTML、PDF 和 Markdown 保留。
- 本次新增 A-051 共 1 讲，详细版共 3 页 PDF、3,080 字符。

[下载全部核心版 ZIP](downloads/study-notes-core.zip) · [本次新增 ZIP](downloads/study-notes-A051.zip) · [已完成总包](downloads/study-notes-all.zip)

核心 ZIP 只含轻量核心 HTML / Markdown 和目录；详细版、PDF 与原视频链接需要联网。总包与新增批次包同时包含对应的详细版和核心版。

## 来源与边界

原视频入口：主页和核心目录的每讲卡片、核心版及详细版导航均保留“▶ 看原视频”；`original-videos.html` 可搜索全部91条原视频，含尚未整理课程。链接跳转至B站；本站不托管原始音视频。

核心版由已校核详细笔记提炼，不是逐字听写。详细版分别标注 `【视频讲解】`、`【整理理解】`、`【补充示例】`；补充练法与规范化例句不是老师原话。机器转写仍可能有误，回看时间为近似定位；以原视频为准。A-031 原视频录制不完整，缺失部分不补造。

本仓库为非官方学习整理，不代表原课程作者授权、认可或发布。原视频及课程内容权利归原权利人；不对原课程内容授予开源许可。不托管原音视频、未校核转写、日志或个人信息。权利人如有异议，可通过仓库 Issues 联系处理。

## 本地预览

本站为静态文件，入口 `index.html`，GitHub Pages 使用 `codex/publish-notes` 分支根目录。

```sh
python3 -m http.server 8770
```

仅发布已经完成校核的笔记，历史批次 ZIP 保留，完成数量不把核心版算作新增课程。
