# B-035｜It did it yesterday｜过去式的随机调用｜核心版

> 第三人称过去肯定句只是入口，真正熟练要能换主语、宾语和时间，并从陈述转到一般疑问和特殊疑问。

## 记住这 3 点

- did是do的过去式；使用did作助动词时，后面的实义动词回到原形。
- 规则／不规则与AAA型是成人整理工具，先练高频词，不能从词形反推新词。
- 成人的“一秒出来”包含陈述、否定、一般疑问和特殊疑问，不直接作为孩子计时门槛。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定一个常用动词，先换主语。
2. 再换名词对象，避免固定短语背诵。
3. 最后练Did、What、How、Why等问句变形。

He cut his finger. / What did he cut? / How did he cut it?

## 易错提醒

- 主语提问Who cut it通常不加did，和宾语提问What did he cut不同。
- 不要让孩子一次完成整套成人问句变形。

**只观察这一件事：**同一个过去动词能否在不同对象中保持过去意义？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-035_It_did_it_yesterday_BV1fqh76fEgW_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1fqh76fEgW/)

视频及课程内容权利归原权利人。
