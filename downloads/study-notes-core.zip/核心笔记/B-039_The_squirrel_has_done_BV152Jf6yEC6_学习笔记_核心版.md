# B-039｜The squirrel has done｜完成时场景分类｜核心版

> 完成时不止“做完了”，还包括经历、次数、持续和最近变化；先选做完与次数两个入口，让孩子在故事和内容包里反复听到第三人称 has done。

## 记住这 3 点

- 完成时常用场景按时间意义区分，不是同一组时间词随意互换。
- 第一轮不必穷尽所有场景；儿童从具体剧情进入，成人按场景逐一穿透。
- The squirrel has done it 强调现在可见结果，主语第三人称单数用 has。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先固定一个角色和一个结果明确的动作。
2. 用 Has the squirrel done it? 做肯定/否定短答，再换角色或物品。
3. 把同一场景带进绘本讨论和日常对话，不只在练习页重复。

The squirrel has hidden the nut. It’s in the box now.

## 易错提醒

- 不要把所有完成时场景做成一天必背清单。
- have/has 随主语变化，过去分词不随主语加 -s。

**只观察这一件事：**孩子能否把 has done 与当前结果或经历意义联系起来？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-039_The_squirrel_has_done_BV152Jf6yEC6_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV152Jf6yEC6/)

视频及课程内容权利归原权利人。
