# B-020｜Let’s do it!｜提议之后，一起做一点｜核心版

> Let’s 加原形用于共同提议。说完不仅停在句首，还要看谁一起做、是否愿意、怎样回应；Let us 与其他代词是分开的可选拓展。

## 记住这 3 点

- Let’s sing.，不是 Let’s to sing／singing。let’s 的撇号保留；lets 可以是另一种动词形式，不能混着写。
- Let us 也可正式提议共同做，如 Let us begin.；也可请求允许，如 Please let us play.。不能说完整形式永远排除听者。
- Let’s 常包括说话者和听者，但并非现场每个人都必须加入。共同提议可接受也可拒绝，不以最终一起做为答对条件。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 成人说 Let’s clap.，孩子愿意就一起拍两下；只先参与动作也有效，不要求马上完整跟说。
2. 给 Let’s… 接 clap；较顺换一个熟悉动作，如 wave，不同时加长宾语和新代词。
3. 愿意时互换提议者，成人回应 Okay／Not now；再用玩偶另轮示范请求允许，不和共同提议首轮混考。

Let’s sing. — Okay. → 一起唱一句；想评价可接 That was fun.，不是每次都得再完成评价句。

## 易错提醒

- Let him／her 加原形，不是 let he／she 或加 to；但这是另轮结构，不因 Let’s 会了就责怪代词还混。
- 场景完整不等于句子必须很长或脑子必须累；疲劳就停，不按几周、句数或每次百分百准确验收。

**只观察这一件事：**孩子把 Let’s… 理解成可接受也可拒绝的共同提议吗？先给真实来回，再看能否少提示说句首。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-020_Let_us_do_it_BV1Vn8M6dErP_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1Vn8M6dErP/)

视频及课程内容权利归原权利人。
