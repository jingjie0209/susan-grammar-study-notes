# A-017｜What's in the sea?｜介词连接名词，接回旧模型｜核心版

> 介词像连接名词的胶水；固定 in 后，把地点和新词串回 There be、问答及简单句模型。

## 记住这 3 点

- 介词常接名词性成分；“胶水”是理解入口，and 也可接词或短语，不能把课堂简化当无例外定义。
- 介词关系用容器、图片和真实位置传递，不只背“in=在里面”。
- 自己加工才是主线：读完合上笔记，用新地点自己组两句；知道别人的模型不等于自己能开口迁移。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用盒子和几张熟悉卡片体验 in：固定 in the box 换物品，不急着同时考问句和复数。
2. 较顺后固定物品换容器；在绘本遇到 zoo 等地点，把它接回 There’s / I can see，而不只报新词。
3. 成人用谁—做什么—地点等模型练替换，不把顺序当所有英文句子的唯一公式；孩子只加接得住的一步。

There's a hamburger in the basin. / Can you see a robot in the zoo?

## 易错提醒

- in 后的动作常用 -ing；like to read 的 to 是不定式标记，不是所有介词都能接 to do。
- 看过讲义不等于会迁移，固定变量后再替换。

**只观察这一件事：**卡在空间关系、名词词汇，还是旧句型连接？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-017_Whats_in_the_sea_BV11Fwjz5EUb.html) · [原视频](https://www.bilibili.com/video/BV11Fwjz5EUb/)

视频及课程内容权利归原权利人。
