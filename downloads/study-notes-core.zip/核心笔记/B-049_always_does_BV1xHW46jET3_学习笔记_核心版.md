# B-049｜always does｜频率与总分表达｜核心版

> Always 与一般现在时第三人称单数结合，表达经常或总是发生的习惯；进一步目标是让一句 main idea 得到三个细节支持。

## 记住这 3 点

- 第三人称实义动词要加 -s/-es，频率副词通常放实义动词前。
- always 可表达高频习惯，也常带夸张或评价色彩。
- 从细节归纳主题和从主题展开细节都要练。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先给人物一个 always 习惯。
2. 找三张图或动作作为支持细节。
3. 口头组成一个主题句加三个细节的四句小段。
4. 每次只增加一个细节，先保证主题和三个细节指向同一人物习惯。

Dad always wears his blue jacket. He wears it at breakfast, outside and at home.

## 易错提醒

- 不要漏掉三单形式。
- 不要把 always 当作严格统计证明。

**只观察这一件事：**孩子说的三个细节是否都支持同一个 always 主题？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-049_always_does_BV1xHW46jET3_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1xHW46jET3/)

视频及课程内容权利归原权利人。
