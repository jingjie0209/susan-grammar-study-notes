# B-012｜Can I do…?｜先问许可，再接真实回应｜核心版

> 把 Can I…? 放进真实、低压力的许可场景。先问、等对方回答，再行动；Could I／May I 是可选扩展，不是儿童礼貌晋级考试。

## 记住这 3 点

- Can I use your pen? 问我能否用；Can you pass me the pen? 请你递笔。行动者与交际功能不同，不套同一个答案。
- can 后接原形，不加 to／-ing。先把 Can I…? 和熟悉动作连上，再加一个明确对象，不同时换全部成分。
- Could I 往往更委婉，May I 通常更正式；不是 Can I 不能问陌生人，也不是 May I 不能问家人。语调、关系和事情本身都重要。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用成人自己的画笔和玩偶示范 Can I use your pen?，等答 Sure 再使用；不扣住孩子必需品逼他说英语。
2. 孩子愿意时给 Can I…? 接 use your pen；先指物、短语或点头都可接，成人完整示范。
3. 固定 use 只换一个熟悉物品；之后让孩子当物主，可答 Yes、Not now 或 No，成人认真回应。

Can I use your pen? — Yes, you can. / Not now. I’m using it.；是否允许按真实情况，不背完就直接拿。

## 易错提醒

- 拒绝不是不配合，礼貌不等于必须答应；水、如厕、安全和身体边界不以完整英文为交换条件。
- 长请求 Could you tell me where…? 与宾语从句属成人拓展；先说清简单请求，不把长句当本轮门槛。

**只观察这一件事：**孩子理解这句话是在等待许可吗？先看交际功能，再看是否能说全，别急着更换三个情态动词。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-012_Can_I_do_BV1uXMD6EE8d_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1uXMD6EE8d/)

视频及课程内容权利归原权利人。
