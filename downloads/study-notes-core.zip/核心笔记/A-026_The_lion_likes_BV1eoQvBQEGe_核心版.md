# A-026｜The lion likes｜把春天说成孩子自己的世界｜核心版

> 这讲不只练 likes 的三单：词法要放进句子反复用；spring 要连接孩子亲身感受过的春天，而不是一个中英等号。

## 记住这 3 点

- 主语换成 he、she、it 或熟悉角色；宾语同时复用名词、宾格代词、冠词和描述。likes 的 s 与 flowers 的复数 s 不是同一回事。
- “一词一世界”是孩子能理解的世界。聊春天先选他看过的花、叶子、天气或活动，不追求一次说完百科知识。
- 同一个句型可以年年再用，随着经历增加新内容；玩具狮子的喜好也可以与家长不同，没有唯一标准答案。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定一个玩具角色，用少量熟悉卡片示范 The lion likes…，再换一个对象。
2. 抽到 spring，就找一张孩子熟悉的照片，只展开颜色或活动中的一个小点。
3. 让孩子给狮子选喜欢的东西；下次换角色或具体细节，继续复用已经会说的词。

The lion likes spring. Look at the flowers. He likes yellow flowers.（规范化补充示例）

## 易错提醒

- 不把每个词都加 s；复数主语应说 The lions like…。
- 不按固定正确率、年龄或年限考核；不要把角色想象当成真实动物知识。

**只观察这一件事：**谈到 spring 时，孩子能否连接到一个自己经历过的具体感知？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-026_The_lion_likes_BV1eoQvBQEGe.html) · [原视频](https://www.bilibili.com/video/BV1eoQvBQEGe/)

视频及课程内容权利归原权利人。
