# B-006｜I’m not doing｜有肯定参照，再理解动作否定｜核心版

> 先理解熟悉动作和 I’m doing，再借眼前事实认识 I’m not doing。否定要说清没在做哪件事，但“不在笑”并不自动等于“在哭”。

## 记住这 3 点

- 语言和情境都要已知：先让动作与肯定句对应，再用 not；卡住时检查词义、所指或情境，不只反复催说。
- 换几个熟悉实例帮助理解模式；课堂三到五例不是固定次数。用短句、动作和表情说明，不让孩子靠背一条句子猜意思。
- 否定放在 am 后，保留 -ing：I am not drawing. / I’m not drawing.；不是 I don’t drawing，也不等于 I can’t draw。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 成人先拍手，再画画，示范 I’m not clapping. I’m drawing.；孩子可先摇头或指图。
2. 孩子词义清楚但句子难时给 I’m not…，让他接 clapping；必要时重演或整句示范。
3. 另轮只换一个熟悉动作。肯定实际动作可由成人补，不要求每次连说两句。

Are you dancing? — No. / No, I’m not.；What are you doing? — I’m drawing.。两个问题功能不同，不套同一个答案。

## 易错提醒

- 否定动作不指定唯一反面；不在跳舞也可能在休息，不必须找一个反义动作。
- 不按固定年龄、天数或句数升级；缩写不是门槛，咬人、抓伤等动作只改成安全图片或玩偶情境。

**只观察这一件事：**换一个熟悉动作后，孩子知道 not 否定的是哪件事吗？先看理解与参与，不只看整句跟读。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-006_I_am_not_doing_BV1EAKH6GEN6_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1EAKH6GEN6/)

视频及课程内容权利归原权利人。
