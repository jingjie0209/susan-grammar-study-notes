# A-018｜What's on the grass?｜on、否定与“会”的层级｜核心版

> 先分层练 on 和 There isn’t，再用间隔回收提升从刻意练习到新场景调用的层级。

## 记住这 3 点

- 本讲从 in 换到 on，并加入不存在的否定；三层变化不要同轮全压。
- 会不是固定次数：能指认、能套句型、能迁移到绘本和讨论，是不同层级。
- 成人可借 -ing 理解名词性用途与修饰语，再用卡片扩展动作；孩子本轮不需要词性分析。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定 on 的真实位置，再替换熟悉物品。
2. 较顺后用 There is / There isn’t 做有/没有对照；若 on 仍陌生，可暂用已熟 in，别把两项新难度一起考。
3. 在新地点、绘本和生活中间隔调取，再加熟悉颜色或动作；只会在原游戏回答，不登记为已全掌握。

There's a book on the table. / There isn't a robot on my arm.

## 易错提醒

- 不以“三遍”“一周”等数字承诺掌握；不把高级 doing 分析变成孩子入场考试。
- 名词卡是思维提示，不必一次要求所有词性变化。

**只观察这一件事：**卡在 on、否定、长句气息，还是成人语法理解？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-018_Whats_on_the_grass_BV1rRwDzvENy.html) · [原视频](https://www.bilibili.com/video/BV1rRwDzvENy/)

视频及课程内容权利归原权利人。
