# A-039｜He is wearing｜用串联练习带动成人与孩子输出｜核心版

> 把 he is wearing 连接衣物、原因、近期绘本与自己已会的句型；成人先练，按孩子反应拆短和辅助，不赶统一进度。

## 记住这 3 点

- 同一剧情可以练 he/she/人名、it/them、问答和否定，逐步选择而非一次叠加。
- because he wants to… 可先由成人清楚示范，孩子未练顺时不强求整句。
- 成人近期的自学和输出给串联提供思路，亲子互动也是练习的一环。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先固定 He is wearing，只换熟悉衣物或人物。
2. 接一个 why 理由：拆成前后两句，成人帮助其中一半。
3. 把昨日绘本里的角色放进来，成人已会时才增加从句。

He is wearing a hat because he wants to dance. / The earthworm is wearing a red hat.

## 易错提醒

- 不按“一周一句”硬过关；不把近期不会的复杂从句变成孩子必考题。
- 孩子开心思考时等待，紧张卡住时及时辅助。

**只观察这一件事：**孩子能否在合适提示下表达自己的理由？看想法、参与和意思确认，不只看 is 是否一次正确。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-039_He_is_wearing_BV1DRLC6EE58.html) · [原视频](https://www.bilibili.com/video/BV1DRLC6EE58/)

视频及课程内容权利归原权利人。
