# B-011｜A fish can do｜先熟悉组合，再少量扩词｜核心版

> 先固定动物，用 can 加熟悉动词原形；不要把“鱼能做的事”列成长表背完。查到新词先筛选，真实能力和想象设定分开。

## 记住这 3 点

- A fish can swim. / The fish can swim.；can 后不加 -s、to 或 -ing。a／the 按场景给完整范例，鱼的复数常仍是 fish。
- 先用已知动作；认出、跟读或复听一份词表，不足以证明换卡后能自己组织。听读仍可支持理解，不必否定。
- 扩词先找熟词的新组合，如 blow bubbles；再按反应选少量真正新词。课堂举的词数不是儿童每轮配额。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 玩具鱼沿桌面游，示范 It can swim.；成人给 It can…，孩子接 swim，指图也算参与。
2. 较顺后固定 fish，只换熟悉的 eat；或另轮固定 swim 换动物，不同时开两张陌生卡。
3. 有画面且想学时，只引入一个新动作／词组；说故事鱼能 sing 时，先确认 pretend 再演。

What can this fish do? — Swim. / It can swim.；成人可补 A fish can swim.，短答不必改考整句。

## 易错提醒

- 一种鱼能做某事，不等于所有鱼都能；科普判断与幻想句分开，不抓活鱼验证。
- 推测、冠词细则与听写迁移供成人回访；must 不只有“必须”一种用法，也不按固定百分比背推测。

**只观察这一件事：**固定动物后，换一个已知动作还能接用 can 吗？卡住先回到接词，不继续塞生词。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-011_A_fish_can_do_BV1ekGF6oEfH_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1ekGF6oEfH/)

视频及课程内容权利归原权利人。
