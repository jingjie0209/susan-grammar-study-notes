# B-036｜The robot didn’t do it yesterday｜过去式收束｜核心版

> 用第三人称否定把过去式的时间、否定、规则／不规则、人称和内容包串联起来；真正会是能继续谈现在与未来。

## 记住这 3 点

- didn’t标记过去，do保持原形；第三人称不再另加三单。
- 四个方向可作成人地图：I did／I didn’t／robot did／robot didn’t。
- 过去事件可以继续讨论地点、工具、感受、现在状态和下一次安排。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用机器人演示没有完成的过去事件。
2. 逐步换常用动词、时间和对象。
3. 从过去回到现在感受和未来安全计划。

The robot didn’t do it yesterday. / What happened next?

## 易错提醒

- 不要把AAA或-ed分组当成推导规则。
- 不要只检查did形式，忽略内容包中的自由交流。

**只观察这一件事：**否定过去式加入后，孩子能否保留角色、事件和时间意义？ 先看意义和来回，再看形式是否稳定。 先看意义和来回，再看形式是否稳定。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-036_The_robot_didnt_do_it_yesterday_BV1bVac6NEBN_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1bVac6NEBN/)

视频及课程内容权利归原权利人。
