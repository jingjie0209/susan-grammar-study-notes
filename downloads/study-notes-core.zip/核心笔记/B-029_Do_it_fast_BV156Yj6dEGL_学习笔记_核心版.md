# B-029｜Do it fast!｜副词修饰动作｜核心版

> fast 在这里修饰 do，给动作增加速度细节。先用熟悉动作理解方式，再迁移到问句和陈述句，不把副词锁在命令句。

## 记住这 3 点

- 副词可说明方式、频率、程度、时间等；fast 先抓速度／方式。
- 形容词修饰名词，如 a fast car；副词修饰动作，如 The car moves fast。fast 本身可作两者。
- 副词应迁移到旧句型，语言网络连接比单独背词更重要。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 纸偶或小车演示 Do it fast，孩子可用动作、fast 或整句回应。
2. 固定 fast 只换一个熟悉动作。
3. 迁移到 The monkey runs fast 或 Can you open it fast?

Do it fast! / The monkey runs fast.

## 易错提醒

- 不是所有副词都机械加 -ly；不要把词形变化当成唯一任务。
- 不为了快做让孩子奔跑、冲撞或做危险动作。

**只观察这一件事：**孩子能否把 fast 与“动作怎样发生”连起来，并迁移一次？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-029_Do_it_fast_BV156Yj6dEGL_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV156Yj6dEGL/)

视频及课程内容权利归原权利人。
