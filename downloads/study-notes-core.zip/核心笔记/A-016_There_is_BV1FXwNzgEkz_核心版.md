# A-016｜There is…｜第一个“硬骨头”分层搭阶梯｜核心版

> There be 同时叠加语序、be、名词、介词和长度；先拆短、固定变量，再长期串联。

## 记住这 3 点

- 先分清“拥有”与“存在”：I have 处理拥有，There is/are 处理某处存在。
- 第一轮先守住 There is/are；过去、将来时与就近原则先由成人理解，不急着让孩子全套输出。
- 省能量也重要：卡片、身体位置、声音和固定回应流程可复用；按孩子反应找适合的模式，不天天购买新道具。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 生活或绘本先预热“哪里有”，成人先自己拆句。
2. 先固定 There is a… 加熟悉名词；另轮用实物练 in/on/under 短语，不同时加入复数和全部地点。
3. 两段较顺后连起来，接着另轮做 There are、数量与换地点；绘本和生活再调取，不只重复一句。

There is a robot in the box. / There are two books on the table.

## 易错提醒

- 不要把中文“有”全翻成 have，也不要一次讲完所有时态和介词。
- 视频中的长期时间说法不是统一达标年限；偶尔出错不等于完全没学会。

**只观察这一件事：**卡在 There is、单复数、介词、地点名词，还是句子太长？一次只支持一处。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-016_There_is_BV1FXwNzgEkz.html) · [原视频](https://www.bilibili.com/video/BV1FXwNzgEkz/)

视频及课程内容权利归原权利人。
