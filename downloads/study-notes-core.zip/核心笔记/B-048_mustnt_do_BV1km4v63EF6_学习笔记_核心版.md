# B-048｜mustn’t do｜禁止与边界｜核心版

> Mustn’t 表示不可以、被禁止，语气强；适合真实危险、规则、健康或伦理边界。亲子日常应慎用，并说明理由和适用范围。

## 记住这 3 点

- mustn’t 不是 don’t have to；前者禁止，后者不必。
- 先分清安全、规则、健康、礼貌和文化场景。
- 强语气不等于羞辱，短安全指令后仍需解释。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用标志或危险图片演示 mustn’t。
2. 把 mustn’t 与 can/don’t have to 分类对比。
3. 每次只练一种场景，并回到真实家庭规则。
4. 每次只换一类规则场景，并回到真实家庭边界，不把文化差异简化成普遍对错。

You mustn’t touch the stove. / You mustn’t smoke here.

## 易错提醒

- 普通请求不宜都用 mustn’t。
- 文化习惯要说明适用范围，不把差异简单判成普遍对错。

**只观察这一件事：**孩子能否把禁令与真实风险或明确规则对应？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-048_mustnt_do_BV1km4v63EF6_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1km4v63EF6/)

视频及课程内容权利归原权利人。
