# A-047｜On the table｜寻物对话，切换 my／your｜核心版

> 把 on the table 放进寻物小故事：一方问“我的在哪里”，另一方答“你的在这里”。先找当前不稳的一个变化轴，不把所有介词和组合一次刷完。

## 记住这 3 点

- my／your 随说话人切换：Where’s my hat? — Your hat is on the table.
- 成人可先扫介词全貌、画图辨意思，但保存图表或 AI 答案不等于会说。
- 所有者、单复数、地点、物品可以分别变；组合多，不代表这一周都要练。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定一件熟悉物品和一个位置，先问答，再交换谁找谁答。
2. 检查卡点在哪，只加一个尚不稳的维度；问句不稳就暂不堆新介词。
3. 隔开再在闯关或绘本找物品；已知句型可连接 where，串几张卡作小复述。

I can’t find my hat. Where’s my hat? — Your hat is on the table.（补充例）

## 易错提醒

- my 后接名词；mine 可独立使用，不把两种结构混写。
- 不要等整张介词表学完才开口；先画清一种位置，马上放进句子，再到新图应用。

**只观察这一件事：**交换角色后能否换对 my／your，并在另一张图里主动问位置？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-047_On_the_table_BV1KeVq6QEvr_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1KeVq6QEvr/)

视频及课程内容权利归原权利人。
