# A-035｜Mr bull doesn’t want｜否定与英语思维加进场景｜核心版

> 用挑剔买家和具体理由练 doesn’t want，再从已知句型出发加一个新词或新维度；英语思维就是用会的结构继续组织新意思。

## 记住这 3 点

- 进入 doesn’t want 前先看 wants 的主语、宾语和基本变量是否已有处理余力，不按固定周数硬推进。
- 购物游戏让 he / she、Does he want…?、Why not? 和 too heavy / too expensive 等理由自然出现，成人先打样再交给孩子。
- 从 it is、has、likes、there is 等已知结构扩展，不背别人写好的台词；错误用于更新家长期待，不用于责备。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 成人用玩偶示范 He doesn’t want it.，再让孩子给挑剔角色选物品。
2. 每轮只加一个具体理由或属性，配合手势、表情和安全假动作传义。
3. 基础骨架顺后换角色，让孩子当卖家；调用旧句型描述商品和原因。

He doesn’t want the hat because it is too heavy.；There is a stain on it.

## 易错提醒

- 先肯定孩子的想法和参与，再给 doesn’t + 原形的正确模型；肯定不等于把错误形式当正确。
- 不要把持续学习理解为背更多固定脚本；每天在语境中拾取一点新东西即可。

**只观察这一件事：**孩子是在不会否定，还是商品、理由和角色都没建立清楚？下一轮只调整一个变量。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-035_%E5%BC%95%E5%AF%BC%E8%BE%93%E5%87%BAA-035_Mr_bull_doesn%27t_want-20260512%E2%9A%A0%EF%B8%8F%E5%A6%82%E4%BD%95%E5%BB%BA%E7%AB%8B%E8%8B%B1%E8%AF%AD%E6%80%9D%E7%BB%B4%EF%BC%9F.html) · [原视频](https://www.bilibili.com/video/BV1xQ5M66EnR/)

视频及课程内容权利归原权利人。
