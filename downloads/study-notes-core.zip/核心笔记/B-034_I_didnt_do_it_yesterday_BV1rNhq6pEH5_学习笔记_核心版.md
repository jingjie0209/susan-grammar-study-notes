# B-034｜I didn’t do it yesterday｜否定过去式｜核心版

> didn’t承担过去和否定，后面动词回到原形；先练常用意义块，再逐步开放时间短语、主语和问句。

## 记住这 3 点

- I didn’t do it yesterday不是I didn’t did it；肯定与否定可成对对比。
- 规则和不规则动词都从常用词进入，成人先做综合输出练习。
- yesterday morning／afternoon等时间短语帮助把事件定位到过去。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定I didn’t，接熟悉原形动作。
2. 用日历或照片演示没有做某事。
3. 顺后再加入主语变化和问句，不一次全开。

I didn’t do it yesterday. / No, I didn’t.

## 易错提醒

- 不要把规则／不规则分类顺序变成孩子的硬门槛。
- 不要把孩子暂时不说当作预热失败。

**只观察这一件事：**孩子是否把“昨天没有做”与didn’t+原形连成整体？ 先看意义和来回，再看形式是否稳定。 先看意义和来回，再看形式是否稳定。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-034_I_didnt_do_it_yesterday_BV1rNhq6pEH5_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1rNhq6pEH5/)

视频及课程内容权利归原权利人。
