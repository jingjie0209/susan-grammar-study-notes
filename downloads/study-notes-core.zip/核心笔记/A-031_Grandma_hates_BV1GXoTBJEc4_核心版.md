# A-031｜Grandma hates｜特指对象，补出理由再串联｜核心版

**来源限制：**标题注明未录全原直播；本笔记只整理可获取的约28分钟语法内容，不补造缺失讲解。

> 用清楚的限定让孩子感到“是这个对象”，再用 hates + 原因把对象、性质和旧句型连成一段；先传义，不把 the 或 why 变成孤立考试。

## 记住这 3 点

- 相似的 loves / hates 仍要分开练：第三人称 s 需要在不同动词和意义里长期输入输出，规则听懂不等于即时会用。
- the 不是见名词就加：用编号、颜色、位置、所属或 in this glass 等限定，让听者知道是哪一个；which 只在有选择时自然加入。
- 孩子没词时先给二选一或三选一，再让他把理由说回整句；辅助要保留思考和参与，不要成人直接抢答。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 摆三个熟悉对象，先练 the second one / the juice in this glass 等可感知限定。
2. 用 Grandma hates… 换对象，再追问 Why?；卡住时给两个原因选择，最后成人补完整模型。
3. 把 hate 带进绘本或生活，换人、换场景做循环复习；基础顺后再加 which、排序或更长原因。

My grandma hates the juice in this glass because it is too sour.；Which one does she hate?

## 易错提醒

- 不要把特指讲成固定米数或冠词表格；孩子先理解对象，再逐步听到形式。
- 不把直播里的年限、正确率当统一达标线，也不把玩具角色喜好当真实动物知识。

**只观察这一件事：**孩子卡住时，问题在对象、限定，还是不会组织 hate 后的原因？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-031_Grandma_hates_BV1GXoTBJEc4.html) · [原视频](https://www.bilibili.com/video/BV1GXoTBJEc4/)

视频及课程内容权利归原权利人。
