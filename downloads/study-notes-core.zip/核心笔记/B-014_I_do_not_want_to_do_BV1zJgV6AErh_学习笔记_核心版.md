# B-014｜I don’t want to do｜先接纳不想做｜核心版

> 孩子说不想做，先接住意愿，再给一个语言支持。don’t want to 后用原形，理由与解决办法都可选；不把 No 变成 Yes 当作练习目标。

## 记住这 3 点

- I don’t want to draw. 表意愿；I can’t draw. 表能力或条件；I’m not drawing. 表当前没在画，不是同一意思。
- 句子加长后可能漏 to、混 don’t／doesn’t，或旧代词出错。观察用于减负和示范，不用于贬低或反复考。
- 孩子可以只说 No，拒绝不需要先说 because 才生效。身体接触、食物和安全边界尤其先尊重意思。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 问 Do you want to sing?，孩子答 No，成人说 Okay. You don’t want to sing.，不继续逼着证明。
2. 愿意练句子时给 I don’t want to… 接 sing；漏 to 就自然重述，再继续玩，不等全对才放行。
3. 玩偶故事中愿意才说 I’m tired. 等理由；提供休息或换活动的选择，最后仍可不参加。

Do you want to draw? — No, I don’t want to draw. — Okay.；想解释再接 I’m tired.，分两句就有效。

## 易错提醒

- 成人也可直接表达边界，不必每次“感谢＋道歉＋理由＋替代”四步齐全；本轮更不要求孩子套公式。
- 故事的解决问题不是劝到答应；飞行、骑动物、摔倒等只用纸偶或图片，不作真实身体挑战。

**只观察这一件事：**成人是否先尊重“不想做”，只补一项语言支持？孩子愿意接词，再逐渐撤提示。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-014_I_do_not_want_to_do_BV1zJgV6AErh_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1zJgV6AErh/)

视频及课程内容权利归原权利人。
