# A-006｜It’s a yellow pear｜颜色放到名词前｜核心版

> 把已熟悉的颜色和名词连接成描述；新增重点是组合结构，而不是又学一堆新词。

## 记住这 3 点

- 先确认旧基础：颜色标签、物体名称和基本句首尽量熟悉；别把新颜色、新名词、新问法同时当输出目标。
- 句子切成小段：yellow book → a yellow book → It’s a yellow book；成人给够模型，再留一小段让孩子接。
- 先分组，后混合：同色换物体练顺；加入新颜色时累计复习旧组，再逐步混色、交换提问角色和迁移场景。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先用熟悉对象和旧句预热，让孩子知道自己能参与；再示范 a yellow pear 这一新组合。
2. 整句难就练短语，能接一小段就留一小段；提示按反应增减，不硬等孩子失败。
3. 同色换熟悉名词，较顺后再换颜色；听懂 Is it a yellow pear? 后逐步引导问答和角色互换。

a yellow pear → It’s a yellow pear.；换熟悉物体：It’s a yellow book.。

## 易错提醒

- 孩子只说 Yes 可能已经正确回应；承接意思、补完整模型，不把简短回应一概判错。
- The pear is yellow. 与 a yellow pear 都能连物体和颜色，但结构不同；不要只背梨这一句。

**只观察这一件事：**换熟悉颜色或名词，还能组合吗？需要的是词汇帮助，还是句子开头？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-006_Its_a_yellow_pear_BV16TftBtEZa.html) · [原视频](https://www.bilibili.com/video/BV16TftBtEZa/)

视频及课程内容权利归原权利人。
