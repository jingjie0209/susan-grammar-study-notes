# B-033｜I did it yesterday｜过去式前的准备｜核心版

> 进入过去式前先看简单句算力、主动词汇、名词代词和内容包；成人提前预热，孩子阶段降低准确率期待。

## 记住这 3 点

- 过去式会让每个动词增加形式选择，基础句若还不能串联，新增负担会过重。
- 成人应提前使用过去式并练自己，从常用动词开始；do、go、see等高频不规则词也要进入网络。
- yesterday是意义入口，不是答题口令；识别、指图和短答都可作为开始。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用照片、日历和生活事件谈昨天。
2. 成人自然示范I did／I went等常用句。
3. 孩子愿意时再从动作或yesterday接到整句。

I did it yesterday. / Yesterday I went to the park.

## 易错提醒

- 不要用固定年龄、几个月或准确率验收。
- 不要把过去式练习变成背完整变形表。

**只观察这一件事：**孩子能否把过去事件与yesterday的意义联系起来？ 先看意义和来回，再看形式是否稳定。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-033_I_did_it_yesterday_BV1N3eX6LEZy_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1N3eX6LEZy/)

视频及课程内容权利归原权利人。
