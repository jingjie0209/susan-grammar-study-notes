# B-046｜don’t have to do｜不必与分条件讨论｜核心版

> Don’t have to 表示解除义务和给予选择，不是 mustn’t 的禁止；同一结论可以用短并列句或 if/when 条件支撑。

## 记住这 3 点

- must do 必须、mustn’t 禁止、don’t have to 不必，三者边界不同。
- 条件越清楚，不必做某事的场景越自然。
- 复杂从句不是唯一表达，简单并列也能传意。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用可见选择建立“可以做也可以不做”。
2. 加入一个真实条件：If you’re full…
3. 把同一场景与 must/mustn’t 对照，只改变一个条件。
4. 每轮只和一个已学义务句比较，避免短答案、条件句和复杂理由同时增加。

If you’re full, you don’t have to eat it.

## 易错提醒

- 不要用 don’t have to 表达禁止。
- 不要给孩子伪选择：不可协商的安全边界应说清楚。

**只观察这一件事：**孩子能否区分“不必”和“不可以”？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-046_dont_have_to_do_BV1ED4g6AEWt_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1ED4g6AEWt/)

视频及课程内容权利归原权利人。
