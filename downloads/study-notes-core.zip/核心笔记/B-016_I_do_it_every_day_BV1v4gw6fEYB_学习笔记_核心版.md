# B-016｜I do it every day｜先懂每天，再连动作｜核心版

> 用孩子反复经历的活动理解 every day，再接一般现在时。先固定 I 与 every day；时态表、often／always 和三单都不必一轮加入。

## 记住这 3 点

- I draw every day.；动作词替换结构中的 do。every day 表“每天”分开写；everyday 常是“日常的”形容词。
- I’m drawing now. 常指当前进行；I draw every day. 是习惯。一般现在时还可说事实与相对稳定情况，不等于“永远不变”。
- 完成形式不总是“全部干完”，完成进行也不必然以后继续。成人的时态地图仅作背景，不给孩子背整表。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 看几次真实刷牙等记录，成人示范 We brush our teeth every day.；不要求先背日历、星期或达到某个年龄。
2. 给 I…every day，让孩子先接熟悉动作或时间块；需要宾语时固定 brush my teeth，不同时换几个部分。
3. 借绘本连接真实习惯；想搞笑时用明确故事角色每天给月亮唱歌，先说明 pretend，不编造孩子真实经历。

Do you draw every day? — Yes. / Not every day.；只画了一次的图，不能据此断言角色每天都画。

## 易错提醒

- 不只凭看到 every day 就机械选时态，要先理解意思；时间概念有个体差异，不设固定年龄判断。
- 幻想只用纸偶、图片或安全动作；不倒挂攀高，不取笑真人，也不把“上瘾”当学习目标。

**只观察这一件事：**孩子能把 every day 与反复发生的事对应吗？意思不清回经历，句长难就托住两端。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-016_I_do_it_every_day_BV1v4gw6fEYB_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1v4gw6fEYB/)

视频及课程内容权利归原权利人。
