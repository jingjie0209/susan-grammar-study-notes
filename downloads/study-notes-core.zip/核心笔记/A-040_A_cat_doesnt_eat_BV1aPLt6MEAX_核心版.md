# A-040｜A cat doesn’t eat｜用否定打开动物话题｜核心版

> 先把 A cat doesn’t eat… 说清，再沿着食物、原因、对比和小故事继续扩展；不要跳过具体剧情直接泛化。

## 记住这 3 点

- doesn’t eat 是具体句型，不等于所有 doesn’t do。
- 否定句同时涉及三单、doesn’t、动词原形和名词。
- 模型需要足够例子但不用穷尽词卡；同一个名词可在已会句型中换主语、宾语或地点角色。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定 eat，只换动物和食物卡。
2. 加入 because、but、so 或 likes to eat 连接两句。
3. 孩子说顺后再进入更多动物饮食表达，不提前堆词性转换。

A cat doesn’t eat carrots, but a rabbit can.

## 易错提醒

- 不要把 don’t/doesn’t、动词还原一次讲完。
- 不要在基础句未自动化时提前大量做词性转换。

**只观察这一件事：**孩子能否从“它不吃什么”继续说出原因或下一步？先看能否维持故事和角色关系，再逐步关注三单、还原和名词形式。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-040_A_cat_doesnt_eat_BV1aPLt6MEAX.html) · [原视频](https://www.bilibili.com/video/BV1aPLt6MEAX/)

视频及课程内容权利归原权利人。
