# A-015｜My mom’s…｜分三路连接，一次变一项｜核心版

> 所属短语分别连接单数、不可数和复数句；用一个变量搭一个场景，别同时换所有东西。

## 记住这 3 点

- 三种材料分层：my mom’s hat、my mom’s juice、my mom’s glasses；先熟悉单个物体，其他方向逐步加入。
- 复数不只改名词：I can see 后改复数，句首不变；这里 They are 还要配合多个对象，可先固定开头练顺。
- 变量就是场景：所有者、物品、数量、是或不是、核实问句，都可成为变化；每轮只加一个主要陌生点。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先用归属清楚的熟悉物体，my mom’s hat → It’s my mom’s hat.；卡住就先练短语。
2. 换熟悉所有者或物品，先不同时换两项；遇到饮料可正确示范 It’s my mom’s juice.。
3. 之后单独练多个物体或眼镜，固定 They are，连接 They are my mom’s glasses.；较顺再加否定或问答。

It’s my mom’s hat. / It’s my mom’s juice. / They are my mom’s glasses.。

## 易错提醒

- 不说 a my mom’s hat，也不因东西“数不完”就当不可数；成人先核对具体用法。
- 成年人的分类与大量练习不是孩子同日作业；实战卡住要看卡点，不只一味增加重复量或强求速度。

**只观察这一件事：**卡住的是所属短语，还是单复数与句首配合？固定其余变量，只补这一段。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-015_My_moms_BV1qGc6z8Eop.html) · [原视频](https://www.bilibili.com/video/BV1qGc6z8Eop/)

视频及课程内容权利归原权利人。
