# A-022｜My dad has…｜三单先练成固定工具｜核心版

> 成人理解三单，孩子先用 My dad has；固定句段做替换，再把 Does he have 作为提问与辅助工具。

## 记住这 3 点

- 开头动词全景是成人地图，不是孩子本讲要会的所有时态；have/has 先对应明确拥有关系。
- 基础停留不是一直讲规则：固定 has 换物品，再换清楚的单个人物，进入颜色、位置等旧场景。
- 一般疑问句给候选，帮助孩子判断；What does he have 答不出时，不只站着等完整答案。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先让玩偶拿熟悉物品，固定 My dad has 换宾语；较顺后再换 My mom 等明确单个人物。
2. 选一个已熟细节做 Zoom in，并在绘本和日常回收；不同时混所有动词和人称。
3. 成人先练顺 Does he have；用对/错候选搭阶梯，陈述较顺后角色互换，让孩子问。

My dad has a book. / Does he have a book? — Yes, he does.

## 易错提醒

- 不说 Does he has；一般现在时也能表示状态，My dad has 不必强加 every day。
- 三单与名词复数的 s 功能不同；视频中的周数、年限不是掌握保证。

**只观察这一件事：**卡在归属、has 句段、宾语，还是提问负荷？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-022_My_dad_has_BV16VXfBAEqc.html) · [原视频](https://www.bilibili.com/video/BV16VXfBAEqc/)

视频及课程内容权利归原权利人。
