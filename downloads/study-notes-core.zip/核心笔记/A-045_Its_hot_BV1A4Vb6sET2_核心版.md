# A-045｜It’s hot｜新形容词串旧句，收尾回主线｜核心版

> 已知区域扩大后，再练 be＋形容词要加入复数、天气和旧句串联；扩展可以有故事，但最后回到 hot／not hot 的目标。

## 记住这 3 点

- 新词有两个方向：放进旧句型，用旧句型讨论这个词；只选实际合适的几句。
- The soup is hot 与 The noodles are hot 要匹配主语；It’s hot 的所指看上下文。
- 成人自练可多发散；孩子首次引入先少而有趣，基础顺后再引导更多话。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定 hot，换熟悉对象说句子，再选玩偶提出“热了怎么办”。
2. 用问题、二选一和自然示范给支架；孩子说对象词时帮他接成句，不板脸逼整句。
3. 理解孩子的理由，再演结果；解决后回到 They’re not hot now 作收尾。

The babies are hot. → Let’s turn on the AC. → They’re not hot now.（玩偶补充例）

## 易错提醒

- close the window 未必错，可能是准备开空调；先问原因，不追预设答案。
- 热物、真实发热和危险动作不拿来试验；这是语言玩偶情景，不是照护建议。

**只观察这一件事：**孩子能否参与想办法；一段扩展后，是否还能说回角色热或不热？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-045_Its_hot_BV1A4Vb6sET2.html) · [原视频](https://www.bilibili.com/video/BV1A4Vb6sET2/)

视频及课程内容权利归原权利人。
