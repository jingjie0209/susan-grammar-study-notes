# A-011｜I can see many things｜复数分组练，继续用｜核心版

> 固定句首引入少量复数；分组练熟悉名词，也让复数继续出现在绘本、扩展和生活里。

## 记住这 3 点

- 本轮主要变名词：先保留 I can see，连接熟悉对象的复数；不是第一周把所有复数变化规则学完。
- 两条线路一起走：熟悉名词分组练，不必按 s、es 规则逐组讲；绘本遇到新例子也可清楚传义、自然使用。
- 成人先练会：核对词形，在固定句首里开口说顺，再换 They are 等表达；新句首与动词配合是另一项难度。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 选几种已经认识的物体，确认有多个；短语难就先练 books / two books，不急着连长句。
2. 接到 I can see two books.，按需要给句首；较顺后加 many、换熟悉对象，不同时全变新。
3. 绘本里看到多个对象时再用，成人可以加清楚的动作或音效；跟着说过，不算以后都能独立调用。

I can see a book. → I can see two books. → I can see many books.。

## 易错提醒

- many 接可数名词复数；通常表示饮料的 juice 不说 many juice，可用 a lot of juice。
- 知道规则不等于能即时组织；“一秒”“第一周”等说法不作统一考核，也不能用简便记忆法推导所有词。

**只观察这一件事：**卡住的是词形、数量短语，还是接上句首？固定其他部分，只补这一小段。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-011_I_can_see_many_things_BV1HXPkzQE6m.html) · [原视频](https://www.bilibili.com/video/BV1HXPkzQE6m/)

视频及课程内容权利归原权利人。
