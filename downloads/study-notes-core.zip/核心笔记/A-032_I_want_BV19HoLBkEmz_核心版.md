# A-032｜I want｜从真实需求进入购物与扩展｜核心版

> 先让孩子在动作和真实需求中理解“想要”，再用 I want 替换对象；基础顺后，从物品自然扩展出属性、数量、购物问答和 want to do。

## 记住这 3 点

- want 与 have 不同：先用孩子真正感兴趣的食物、球或玩具传递“想要”，不要只靠闪卡或字典定义。
- 闪卡主要用于大量替换和提供思路；a / the / some、What kind of、How many 等都放进清楚场景，不一次塞成规则考试。
- 成人在给东西时自然说 Here you are / There you go；孩子卡住时给句首或选择，别用固定台词替代他自己组句。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先用 Do you want it? 传递意思，孩子理解后再接 Yes, I want the… 。
2. 换书、铅笔、船等熟悉卡片，只展开一个维度：大小、颜色、材质、用途或数量。
3. 玩简短买东西游戏；基础稳定后示范 I want to sleep / play 等 want to do，并配动作。

Do you want the book? — Yes, I want the book.；What kind of boat do you want?

## 易错提醒

- 不要把“听过一遍”当成孩子能独立输出，也不要一次背五十句购物脚本。
- 传义可用真实动作，复习再用卡片；尊重想要／不想要的选择，不拿实物交换逼孩子说句子。

**只观察这一件事：**孩子是真懂“想要”，还是只会跟着卡片说 I want？他卡在对象、句首还是扩展维度？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-032_I_want_BV19HoLBkEmz.html) · [原视频](https://www.bilibili.com/video/BV19HoLBkEmz/)

视频及课程内容权利归原权利人。
