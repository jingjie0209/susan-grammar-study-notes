# B-002｜You’re doing｜我演你猜，按反应撤提示｜核心版

> 要让孩子说 You’re doing，就给他描述对方动作的理由。用“我演你猜”提供场景，先示范、再等待，I与you跟着说话者转换。

## 记住这 3 点

- act这类词可通过几次完整演与猜逐渐理解；“五三原则”不是固定五遍示范、三遍考核，也不期待一次就会。
- 需要整句就示范，能接动作词就只给 You’re…；已经会起句就等，不替孩子抢答。成人表演不清楚时，也允许猜不出。
- -ing拼写主要供成人准备：study→studying，make→making，run→running，lie→lying；不是所有词都直接加，也不是儿童开口前必须会拼。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 成人用空杯假装喝水，问 What am I doing?，必要时从孩子视角示范 You’re drinking.。
2. 换成唱歌或画画，逐渐只给句首；猜不出可重演或给两个清楚选项。
3. 愿意时互换角色：孩子演，问 What are you doing?，孩子可答 I’m…；只加一个地点或角色继续玩。

成人：What am I doing? → 孩子：You’re singing.；交换角色后：What are you doing? → I’m singing.。

## 易错提醒

- 不同问句有不同功能，No等短答有效；不逼每个问题都附加整句，不把提示次数变成分数。
- -ing形式可有不同句法功能，不全是形容词；躲藏只用玩具和安全位置，不放物品进耳鼻。

**只观察这一件事：**换一个动作后，孩子是在描述面前的人，还是照背成人的 I’m？若视角混淆，先固定角色，不再加新词。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-002_You_are_doing_BV1nE7P6tESR_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1nE7P6tESR/)

视频及课程内容权利归原权利人。
