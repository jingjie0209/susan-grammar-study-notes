# B-022｜I hate doing｜讨厌某个动作｜核心版

> 用 hate doing 表达具体情境中的感受，注意主动与被动不同。观点可以变化，孩子可拒绝或用短语、手势回应。

## 记住这 3 点

- I hate spraying water 与 I hate being sprayed 不是同一件事，先演清楚谁在做。
- 动名词前可以有逻辑主语，如 her／anyone；这是成人拓展，不是幼儿必须拆解的术语。
- hate、like、don’t like 要随真实场景变化，不强迫孩子对某动作给固定答案。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 固定 I hate，孩子接熟悉动作。
2. 用两个玩偶演主动／被动，再由成人示范完整句。
3. 顺后只换一个动作或对象，不把被动、长宾语和新词同轮混入。

I hate spraying water. / I hate being sprayed.

## 易错提醒

- 不把 hate 变成强烈观点的固定刻度；孩子说 No 或不参与也有效。
- 不为了练句型制造喷水、热汤等不舒服或不安全情境。

**只观察这一件事：**孩子是否知道“我做”和“别人对我做”是不同事件？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-022_I_hate_doing_BV1wihg67EoB_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1wihg67EoB/)

视频及课程内容权利归原权利人。
