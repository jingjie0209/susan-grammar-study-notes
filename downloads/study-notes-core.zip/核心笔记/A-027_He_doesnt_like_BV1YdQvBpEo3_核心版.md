# A-027｜He doesn’t like｜先帮表达，再温和纠错｜核心版

> 重点是一整套互动：意思清楚、不会就辅助、说错给正确模型；用商量和选择延续对话，不把练否定变成命令或责问。

## 记住这 3 点

- 第三人称单数否定用 doesn’t like，like 保持原形；doesn’t have 是没有，doesn’t like 是不喜欢，意思不同。
- 先通过角色、分堆、表情和动作传递意思。孩子没反应时，分清是对象不懂、正反意思不懂，还是整句难说。
- 游戏里要复习、给支持和正反馈，结束时说一个具体小进步；再把句子带进看图或日常，不只在抽卡时使用。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 让玩具把熟悉对象分成喜欢和不喜欢两区，孩子决定角色喜好，家长示范对应句。
2. 孩子说 he don’t like 时，自然接 He doesn’t like…；用有趣声音或下一轮游戏复用，不逼当场反复认错。
3. 接一条简单描述，再商量 Shall we choose another one?；允许孩子真选、真回答。

He doesn’t like this picture. It’s too dark. Shall we choose another one?（规范化补充示例）

## 易错提醒

- 不说 He doesn’t likes…，也不把没有与不喜欢混用。
- 夸的是尝试和进步，不是把错误判为正确；不以两天全对为门槛。

**只观察这一件事：**孩子卡住或说错后，家长能否给到支持，让对话仍继续？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-027_He_doesnt_like_BV1YdQvBpEo3.html) · [原视频](https://www.bilibili.com/video/BV1YdQvBpEo3/)

视频及课程内容权利归原权利人。
