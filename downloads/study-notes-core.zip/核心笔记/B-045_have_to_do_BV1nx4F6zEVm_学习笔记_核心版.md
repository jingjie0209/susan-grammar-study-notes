# B-045｜have to do｜客观义务｜核心版

> Have to do 更像普通动词结构，会随时态和人称变化，常表达客观条件造成的“不得不”；要把重要性、抗拒、后果和义务说进同一场景。

## 记住这 3 点

- 第三人称用 has to，过去用 had to，疑问/否定借助 do。
- have to 常强调客观必要，must 更常强调主观必须。
- 到 B 阶段要把动词卡看成带宾语、状语、可扩展的集合。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 选一件真实小义务并说清背景。
2. 用 You have to… 给出边界，再接一个可见后果。
3. 孩子先执行或说动作，稳定后再补完整理由。
4. 把同一个 have to 换到真实家庭任务和不同人物，观察成人重组是否顺畅。

You have to put the toothbrush back. / He has to go to school.

## 易错提醒

- 不要用制造恐惧来证明“必须”。
- don’t have to 是不必，不是禁止。

**只观察这一件事：**孩子是否理解“不想做”和“仍然必须”能同时存在？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-045_have_to_do_BV1nx4F6zEVm_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1nx4F6zEVm/)

视频及课程内容权利归原权利人。
