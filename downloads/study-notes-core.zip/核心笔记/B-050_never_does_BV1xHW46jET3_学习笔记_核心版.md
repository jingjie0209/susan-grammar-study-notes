# B-050｜never does｜否定频率与证据｜核心版

> Never 表示从不，本身已带否定；第三人称一般现在时仍要保持动词三单。与 always 共用总分结构，但细节必须真的支持“从不”的结论。

## 记住这 3 点

- He never goes 中 never 不替代三单 goes。
- never 是频率零，不等于过去时或完成时专用。
- 用 never 描述人物习惯需要足够证据，避免给真实人物贴绝对标签。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用三张图建立“总是—有时—从不”的频率尺度。
2. 给一个 never 主题，再找三件事支持。
3. 区分虚构角色设定与真实人物评价。
4. 每次只换一个真实细节，先保证主题和三个细节都支持 never。

The robot never eats human food. It only charges.

## 易错提醒

- 不要在 never 句里再加 don’t/doesn’t。
- 不要把一次行为概括成 never。

**只观察这一件事：**孩子能否理解 never 的否定频率，并用多个证据支撑主题？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-050_never_does_BV1xHW46jET3_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1xHW46jET3/)

视频及课程内容权利归原权利人。
