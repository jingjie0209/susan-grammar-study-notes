# A-049｜Under the bed｜输出定进度，双向循环复习｜核心版

> in／on／under 能否加速，要看是否真的会用，而非年龄或上课周数。组句里练的回绘本用，绘本里新学的再放进组句，形成双向复习。

## 记住这 3 点

- 组句目标回绘本找图应用；绘本新词再放进角色台词或行动，旧句与新词一起调取。
- 成人自练时带动作、表情和意思一起练；孩子已顺才加新介词，不按列表一次全学。
- 介词后表达动作时练 -ing：good at drawing、Thank you for helping me；名词限定词另看用法。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 用安全玩偶摆 under the bed，说位置并交换指令；成人带动作把意思一起练。
2. 读图找相同位置关系，也可在纸面想象与角色互动，不改写原书事实。
3. 挑昨天绘本里一个新词，让当前游戏角色再用；只加一步，已顺再进下一项。

The giraffe is under the bed. / Thank you for helping me.（补充例，分开练）

## 易错提醒

- at／on／in 不按面积硬排；between 不仅限两个；under my bed 不再加 the，介词后动作留意 -ing。
- 不钻真实床底或追跑来测位置；记不住不一概归因于加多，笔记和间隔复习都可辅助。

**只观察这一件事：**新场景里能否再用目标关系，并让一个近期学过的词自然回到表达里？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/A-049_Under_the_bed_BV1heEM6oE3z_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1heEM6oE3z/)

视频及课程内容权利归原权利人。
