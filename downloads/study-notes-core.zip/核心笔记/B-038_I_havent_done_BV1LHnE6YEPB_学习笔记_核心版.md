# B-038｜I haven’t done｜完成时第二讲｜核心版

> 先理解完成时是站在现在做截止总结，再用“结果场景＋三句时态对照”练过去分词；否定用 haven’t/hasn’t + 过去分词，课堂重点是成人先会、孩子长输入。

## 记住这 3 点

- 完成时总结截至现在的结果、经历、次数或持续；一般过去时讲具体过去事件。
- 过去分词要按高频词逐步积累，成人每次先想完整场景再说句子。
- I haven’t done it yet 表示到现在仍未完成，不等同于过去式 I didn’t do it.

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 先固定一个有可见结果的任务，建立 Have you done it? — Yes/No 的一来一回。
2. 成人按一般现在→一般过去→现在完成连说三句，再补现在结果。
3. 孩子只先听和接短答，等结果场景稳定后再加 yet、before 或次数。

I clean my room every day. / I cleaned it yesterday. / I’ve cleaned it. It’s clean now.

## 易错提醒

- 不要把过去式与过去分词混为一列，也不要只靠抄写记不规则词。
- 不要用完成时强绑 yesterday 等明确过去时间点；先看观察点在现在还是过去。

**只观察这一件事：**孩子能否把“已经／还没完成”与眼前结果对应，而不是只模仿 have done 的声音？

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-038_I_havent_done_BV1LHnE6YEPB_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1LHnE6YEPB/)

视频及课程内容权利归原权利人。
