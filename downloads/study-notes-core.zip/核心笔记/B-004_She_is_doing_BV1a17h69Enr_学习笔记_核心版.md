# B-004｜She’s doing｜先抓眼前，再按情境扩展进行时｜核心版

> 先让 She’s doing 对应眼前动作，再按需要区分近期暂时活动、变化或带情绪的重复。now是起步帮助，不是唯一规则，也不是每句必带。

## 记住这 3 点

- She draws after school.说常态，She’s drawing now.说当前活动；先固定一个明确角色和一个时间情境，不同时换一切。
- 课堂列出的进行时情境有重叠，不是六个互斥格子。近期活动可用 these days／this week，always也不只表示抱怨。
- 旧代词、对象词和前一天绘本的新词可按需回收；一次只选一项，不要求每句覆盖全部旧知识。

## 怎么练 · 3 步

以下为整理者补充练法与规范化例句，不是视频原话或统一作业。

1. 介绍玩偶 Maya，边演边问 What is she doing?，示范 She’s drawing.。
2. 需要时给 She’s…让孩子接；较顺后只加 now或一个对象，再换动作。
3. 愿意继续时换明确角色；近期活动或always另轮回访，成人先确认孩子理解，不把情境表当闯关表。

She’s drawing now. / She’s learning to draw these days. —— 两种情境分轮，后一项是可选回访，不是当轮必做。

## 易错提醒

- 不靠某个时间词一对一判时态，不把“瞬间动作不能用进行式”作通则，也不机械套 Recently I’m…。
- always故事用约定玩偶，不点名取笑真实同学；不要求多年代数或每天固定练习量。

**只观察这一件事：**孩子能否根据画面理解她正在做什么，而不是只看见now就背句？接不住时退回眼前动作，扩展不是越多越好。

依据已校核详细笔记提炼，非逐字记录；可能有识别与整理偏差，请以原视频为准。

[详细版](https://jingjie0209.github.io/susan-grammar-study-notes/%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/B-004_She_is_doing_BV1a17h69Enr_%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0.html) · [原视频](https://www.bilibili.com/video/BV1a17h69Enr/)

视频及课程内容权利归原权利人。
